//
//  Sports.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 02/01/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class Sports: BaseViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = sportsView.dequeueReusableCell(withIdentifier: "cell") as! SportsTableViewCell
        cell.title1.text = titleArray[indexPath.row]
        cell.sportsImage!.image = UIImage(named: imageArray[indexPath.row])
        return cell
    }
    

    @IBOutlet weak var sportsView: UITableView!
    var titleArray = ["Gymnasium","Swimming","Out Door Facilities","In Door Facilities","Hire Basis"]
    var imageArray = ["gym.jpg","swimming.jpg","outdoor.jpg","indoor.jpg","rent.jpg"]
    
    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
