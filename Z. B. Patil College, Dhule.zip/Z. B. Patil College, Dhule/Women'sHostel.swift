//
//  Women'sHostel.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 02/01/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class Women_sHostel: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return facilityArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell.init(style: .value1, reuseIdentifier: "cell")
        cell.textLabel?.text = facilityArray[indexPath.row]
        cell.detailTextLabel?.text = intakeArray[indexPath.row]
        return cell
    }

    @IBOutlet weak var hostelImage: UIImageView!
    @IBOutlet weak var hostelView: UITableView!
    var facilityArray = ["Facilities","Total Rooms","Office","Kitchen","Store Room","Dinning Hall","Solar Water Heater"]
    var intakeArray = ["Intake","34","1","1","1","1","1"]

    override func viewDidLoad() {
        addSlideMenuButton()
        hostelImage.layer.cornerRadius = 20.0
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
