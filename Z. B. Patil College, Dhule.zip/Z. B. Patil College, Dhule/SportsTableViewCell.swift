//
//  SportsTableViewCell.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 03/03/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class SportsTableViewCell: UITableViewCell {

    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var sportsImage: UIImageView!
    @IBOutlet weak var title1: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        view2.layer.cornerRadius = 10.0
        sportsImage.layer.cornerRadius = 10.0
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
