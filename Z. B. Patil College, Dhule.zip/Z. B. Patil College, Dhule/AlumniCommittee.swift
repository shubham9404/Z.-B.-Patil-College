//
//  AlumniCommittee.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 23/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class AlumniCommittee: BaseViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var committeeTableView: UITableView!
    
    var alumniCommitteeName = ["Dr. P. H. Pawar","Dr. A. A. Patil","Dr. Sharda J. Shitole","Dr. Vidya Patil","Dr. C. N. Pagare","Mr. A. N. Kharwandikar",""]
    
    var alumniCommitteePost = ["Pripal","Vice Principal","Vice Principal","Vice Principal","Vice Principal","",""]
    
    var alumniAdhocCommitteeName = ["Mr. Girish B. Desale","Mr. Dipak S. Chaudhari","Mrs. Kalpana R. Patil"]
    
    var alumniAdhocCommitteePost = ["President","Secretary","Treasure"]
    
    var alumniHeading = ["Advisory Committee","Adhoc Committee"]
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return alumniCommitteeName.count
        }
        else
        {
            return alumniAdhocCommitteeName.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = UITableViewCell(style: .value1, reuseIdentifier: "cell1")
        if indexPath.section == 0
        {
            cell1.textLabel?.text = alumniCommitteeName[indexPath.row]
            cell1.detailTextLabel?.text = alumniCommitteePost[indexPath.row]
        }
        else
        {
            cell1.textLabel?.text = alumniAdhocCommitteeName[indexPath.row]
            cell1.detailTextLabel?.text = alumniAdhocCommitteePost[indexPath.row]
        }
        return cell1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return alumniHeading[section]
    }
    

    override func viewDidLoad() {
        committeeTableView.dataSource = self
        committeeTableView.delegate = self
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
