//
//  SlideMenu.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 18/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit
protocol SlideMenuDelegate
{
    func slideMenuItemSelectedAtIndex(_ index : Int32)
}
class SlideMenu: UIViewController {

    @IBOutlet weak var CollegeLogo: UIImageView!
    
    @IBOutlet weak var btnCloseMenuOverlay: UIButton!
    var btnMenu : UIButton!
    var delegate : SlideMenuDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnCloseTapped(_ sender: UIButton) {
        
        btnMenu.tag = 0
        btnMenu.isHidden = false
        if (self.delegate != nil)
        {
            var index = Int32(sender.tag)
            if (sender == self.btnCloseMenuOverlay)
            {
                index = -1
            }
            delegate?.slideMenuItemSelectedAtIndex(index)
        }
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            self.view.layoutIfNeeded()
            self.view.backgroundColor = UIColor.clear
        }, completion : { (finished) -> Void in
            self.view.removeFromSuperview()
            self.removeFromParent()
            
       
        })
    }
    
    @IBAction func HomeButtom(_ sender: UIButton) {
        let gohome = storyboard?.instantiateViewController(withIdentifier: "HomePage") as! HomePage
        navigationController?.pushViewController(gohome, animated: true)
    }
    
    @IBOutlet var bOutletCollection: [UIButton]!
    
    @IBAction func AboutUs(_ sender: Any) {
        bOutletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
    }
    }
    
    @IBAction func aboutUsPage(_ sender: UIButton) {
        let goabout = storyboard?.instantiateViewController(withIdentifier: "About") as! About
        navigationController?.pushViewController(goabout, animated: true)
    }
    
    @IBAction func goPDP(_ sender: UIButton) {
        let pdpage = storyboard?.instantiateViewController(withIdentifier: "PrincipalDesk") as! PrincipalDesk
        navigationController?.pushViewController(pdpage, animated: true)
    }
    
    @IBAction func goCDP(_ sender: Any) {
        let cdpage = storyboard?.instantiateViewController(withIdentifier: "ChairmanDesk") as! ChairmanDesk
        navigationController?.pushViewController(cdpage, animated: true)
    }
    
    
    @IBOutlet var academicsOuletCollection: [UIButton]!
    
    @IBAction func academics(_ sender: UIButton) {
        academicsOuletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
    }
    }
    
    @IBAction func faculty(_ sender: UIButton) {
        let goFaculty = storyboard?.instantiateViewController(withIdentifier: "Faculty") as! Faculty
        navigationController?.pushViewController(goFaculty, animated: true)
    }
    
    @IBAction func addOnCourse(_ sender: Any) {
        let course = storyboard?.instantiateViewController(withIdentifier: "AddOnCourse") as! AddOnCourse
        navigationController?.pushViewController(course, animated: true)
    }
    
    @IBAction func research(_ sender: Any) {
        let research = storyboard?.instantiateViewController(withIdentifier: "Reasearch") as! Reasearch
        navigationController?.pushViewController(research, animated: true)
    }
    
    @IBAction func placement(_ sender: Any) {
        let place = storyboard?.instantiateViewController(withIdentifier: "Placements") as! Placements
        navigationController?.pushViewController(place, animated: true)
    }
    
    @IBAction func comities(_ sender: Any) {
        let comiti = storyboard?.instantiateViewController(withIdentifier: "Comities") as! Comities
        navigationController?.pushViewController(comiti, animated: true)
    }
    
    @IBAction func eContent(_ sender: Any) {
        let econtent = storyboard?.instantiateViewController(withIdentifier: "EContent") as! EContent
        navigationController?.pushViewController(econtent, animated: true)
    }
    
    @IBOutlet var facilitiesOutletCollection: [UIButton]!
    
    @IBAction func gofacilities(_ sender: Any) {
        facilitiesOutletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
    }
    
    }
    
    
    @IBOutlet weak var goAdmission: UIButton!
    
    @IBOutlet var activitiesOutletCollection: [UIButton]!
    
    
    @IBAction func goActivities(_ sender: Any) {
        activitiesOutletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
    }
}
    
    @IBOutlet var alumniOutletCollection: [UIButton]!
    
    @IBAction func goAlumni(_ sender: UIButton) {
        alumniOutletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
    }
    }
    
    @IBAction func goAlumniEngagement(_ sender: Any) {
        let goAlumniE = storyboard?.instantiateViewController(withIdentifier: "AlumniEngagement") as! AlumniEngagement
        navigationController?.pushViewController(goAlumniE, animated: true)
    }
    
    @IBAction func goAlumniCommittees(_ sender: UIButton) {
        let goAlumniC = storyboard?.instantiateViewController(withIdentifier: "AlumniCommittee") as! AlumniCommittee
        navigationController?.pushViewController(goAlumniC, animated: true)
    }
    
    @IBAction func goAlumniActivities(_ sender: Any) {
        let goAlumniA = storyboard?.instantiateViewController(withIdentifier: "AlumniActivities") as! AlumniActivities
        navigationController?.pushViewController(goAlumniA, animated: true)
    }
    
    @IBAction func goAlumniOurPride(_ sender: Any) {
        let goAlumniOP = storyboard?.instantiateViewController(withIdentifier: "AlumniOurPride") as! AlumniOurPride
        navigationController?.pushViewController(goAlumniOP, animated: true)
    }
    @IBAction func contactUs(_ sender: UIButton) {
        let cupage = storyboard?.instantiateViewController(withIdentifier: "ContactUs") as! ContactUs
        navigationController?.pushViewController(cupage, animated: true)
    }
    
    @IBAction func establishment(_ sender: Any) {
        let estabpage = storyboard?.instantiateViewController(withIdentifier: "Establishment") as! Establishment
        navigationController?.pushViewController(estabpage, animated: true)
    }
    
    
    @IBAction func manage(_ sender: Any) {
        let managepage = storyboard?.instantiateViewController(withIdentifier: "Management") as! Management
        navigationController?.pushViewController(managepage, animated: true)
    }
    
    @IBAction func coreValues(_ sender: Any) {
        let corevaluepage = storyboard?.instantiateViewController(withIdentifier: "CoreValues") as! CoreValues
        navigationController?.pushViewController(corevaluepage, animated: true)
    }
    
    @IBAction func codeofConduct(_ sender: Any) {
        let codeofconductpage = storyboard?.instantiateViewController(withIdentifier: "CodeofConduct") as! CodeofConduct
        navigationController?.pushViewController(codeofconductpage, animated: true)
    }
    
    @IBAction func reaching(_ sender: Any) {
        let reachpage = storyboard?.instantiateViewController(withIdentifier: "Reaching") as! Reaching
        navigationController?.pushViewController(reachpage, animated: true)
    }
    
    @IBAction func admini(_ sender: Any) {
        let adminipage = storyboard?.instantiateViewController(withIdentifier: "Administration") as! Administration
        navigationController?.pushViewController(adminipage, animated: true)
    }
    
    @IBAction func Colaboration(_ sender: Any) {
        let colabpage = storyboard?.instantiateViewController(withIdentifier: "Colaboration") as! Colaboration
        navigationController?.pushViewController(colabpage, animated: true)
    }
    
    @IBAction func Award(_ sender: Any) {
        let award = storyboard?.instantiateViewController(withIdentifier:"Awards") as! Awards
        navigationController?.pushViewController(award, animated: true)
    }
    
    @IBAction func Recognition(_ sender: Any) {
        let recogpage = storyboard?.instantiateViewController(withIdentifier: "Recognition") as! Recognition
        navigationController?.pushViewController(recogpage, animated: true)
    }
    
    @IBAction func Calander(_ sender: Any) {
        let calanpage = storyboard?.instantiateViewController(withIdentifier: "Calander") as! Calander
        navigationController?.pushViewController(calanpage, animated: true)
    }
    
    @IBAction func PhotoGa(_ sender: Any) {
        let photopage = storyboard?.instantiateViewController(withIdentifier:"Photo") as! Photo
        navigationController?.pushViewController(photopage
            , animated: true)
    }
    
    @IBAction func liabrary(_ sender: Any) {
        let liabrary = storyboard?.instantiateViewController(withIdentifier: "Liabrary") as! Liabrary
        navigationController?.pushViewController(liabrary, animated: true)
    }
    
    @IBAction func ComputerCenter(_ sender: Any) {
        let compcen = storyboard?.instantiateViewController(withIdentifier:"ComputerCenter") as! ComputerCenter
        navigationController?.pushViewController(compcen, animated: true)
    }
    
    @IBAction func Sports(_ sender: Any) {
        let sports = storyboard?.instantiateViewController(withIdentifier: "Sports") as! Sports
        navigationController?.pushViewController(sports, animated: true)
    }
    
    @IBAction func ConferenceHall(_ sender: Any) {
        let confer = storyboard?.instantiateViewController(withIdentifier: "ConferenceHall") as! ConferenceHall
        navigationController?.pushViewController(confer, animated: true)
    }
    
    @IBAction func WomensHostel(_ sender: Any) {
        let womenhos = storyboard?.instantiateViewController(withIdentifier: "Women_sHostel") as! Women_sHostel
        navigationController?.pushViewController(womenhos, animated: true)
    }
    
    @IBAction func CollegeCanteen(_ sender: Any) {
        let canteen = storyboard?.instantiateViewController(withIdentifier: "CollegeCanteen") as! CollegeCanteen
        navigationController?.pushViewController(canteen, animated: true)
    }
    
    @IBAction func Bank(_ sender: Any) {
        let bank = storyboard?.instantiateViewController(withIdentifier: "Bank") as! Bank
        navigationController?.pushViewController(bank, animated: true)
    }
    
    @IBAction func LeadiesRoom(_ sender: Any) {
        let lr = storyboard?.instantiateViewController(withIdentifier: "LeadiesRoom") as! LeadiesRoom
        navigationController?.pushViewController(lr, animated: true)
    }
    
    @IBAction func PhotoCopyCenter(_ sender: Any) {
        let photocopy = storyboard?.instantiateViewController(withIdentifier: "PhotocopyCenter") as! PhotocopyCenter
        navigationController?.pushViewController(photocopy, animated: true)
    }
    
    @IBAction func StudentConsumerStore(_ sender: Any) {
        let studentcorner = storyboard?.instantiateViewController(withIdentifier: "StudentConsumerCenter") as! StudentConsumerCenter
        navigationController?.pushViewController(studentcorner, animated: true)
    }
    
    @IBAction func Admi(_ sender: Any) {
        let add = storyboard?.instantiateViewController(withIdentifier: "Admissn") as! Admissn
        navigationController?.pushViewController(add, animated: true)
    }
    
    @IBAction func ncc(_ sender: Any) {
        let ncc = storyboard?.instantiateViewController(withIdentifier: "NCC") as! NCC
        navigationController?.pushViewController(ncc, animated: true)
    }
    
    @IBAction func nss(_ sender: Any) {
        let nss = storyboard?.instantiateViewController(withIdentifier: "NSS") as! NSS
        navigationController?.pushViewController(nss, animated: true)
    }
    
    @IBAction func sport(_ sender: Any) {
        let spo = storyboard?.instantiateViewController(withIdentifier: "Sport") as! Sport
        navigationController?.pushViewController(spo, animated: true)
    }
    
    @IBAction func yuvarang(_ sender: Any) {
        let yuva = storyboard?.instantiateViewController(withIdentifier: "Yuvarang") as! Yuvarang
        navigationController?.pushViewController(yuva, animated: true)
    }
    
    @IBAction func gathering(_ sender: Any) {
        let gather = storyboard?.instantiateViewController(withIdentifier: "Gathering") as! Gathering
        navigationController?.pushViewController(gather, animated: true)
    }
    
    @IBAction func yuvati(_ sender: Any) {
        let yuvati = storyboard?.instantiateViewController(withIdentifier: "YuvatiSabha") as! YuvatiSabha
        navigationController?.pushViewController(yuvati, animated: true)
    }
    
    @IBAction func lecture(_ sender: Any) {
        let lecture = storyboard?.instantiateViewController(withIdentifier: "LectureSeries") as! LectureSeries
        navigationController?.pushViewController(lecture, animated: true)
    }
    
    @IBAction func netaji(_ sender: Any) {
        let netaji = storyboard?.instantiateViewController(withIdentifier: "NetajiJayanti") as! NetajiJayanti
        navigationController?.pushViewController(netaji, animated: true)
    }
    
    
}
