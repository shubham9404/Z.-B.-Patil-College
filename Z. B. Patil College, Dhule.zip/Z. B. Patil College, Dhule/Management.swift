//
//  Management.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 30/12/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class Management: BaseViewController, UITableViewDataSource,UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = managemntTableView.dequeueReusableCell(withIdentifier: "cell") as! ManagementTableViewCell
        let imageName = UIImage(named: imageArray[indexPath.row])
        cell.imageView?.image = imageName
        cell.name.text = nameArray[indexPath.row]
        cell.designation.text = designationArray[indexPath.row]
        return cell
    }
    
    @IBOutlet weak var managemntTableView: UITableView!
    
    
    
    var imageArray = ["Salunkhe.jpg","pgp.jpg","Bhadane.jpg","Chairman1.jpeg","SPatil.jpg","psc.jpg","cvp.jpg","More.jpg","ss.jpg","adc.jpg","NPatil.jpg","nhp.jpg","sss.jpg","voi.jpg","n1.jpg",]
    
    var nameArray = ["Dr. Arun Zulalrao Salunkhe","Shri. Pramod Gulabrao Patil","Shri Pradip Hiraji Bhadane","Shri Vijay Pitambar Patil","Shri Sudhir S. Patil","Sau Pratibhatai S. Chaudhari","Shri Chandrashekhar V. Patil","Shri Ajit Sukdevrao More","Shri Shekhar R. Surywanshi","Dr. Anil Digambar Chaudhari","Adv. Shri Rajen Natthu Patil","Dr. Nilima Himmatrao Patil","Sau Smita S. Salunkhe","Shri Vasantrao Onkar Ishi","Shri Nanabhau Rajsinh Kor"]
    
    var designationArray = ["Chairman","Vice Chairnam","Secretory","Director","Director","Director","Director","Director","Director","Director","Director","Director","Director","Director","Director"]

    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
