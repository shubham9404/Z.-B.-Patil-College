//
//  HomePage.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 16/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class HomePage:  BaseViewController {

    @IBOutlet weak var View1: UIView!
    
    @IBOutlet weak var CollegeLogo: UIImageView!
    
    @IBOutlet weak var Title1: UILabel!
    
    @IBOutlet weak var Title2: UILabel!
    
    @IBOutlet weak var Slogan: UILabel!
    
    @IBOutlet weak var SubTitle: UILabel!
    
    @IBOutlet weak var View2: UIView!
    
    @IBOutlet weak var CollegeCampus: UIImageView!
    
    @IBOutlet weak var View3: UIView!
    
    @IBOutlet weak var ZBP: UIImageView!
    
    @IBOutlet weak var ZBPText: UITextView!
    
    @IBOutlet weak var View4: UIView!
    
    @IBOutlet weak var Principal: UIImageView!
    
    @IBOutlet weak var PHPLable: UILabel!
    
    @IBOutlet weak var Chairman: UIImageView!
    
    @IBOutlet weak var ChairmanLable: UILabel!
    
    @IBOutlet weak var View5: UIView!
    
    @IBOutlet weak var MissionStatement: UILabel!
    
    @IBOutlet weak var MSText: UITextView!
    
    @IBOutlet weak var Vision: UILabel!
    
    @IBOutlet weak var VText: UITextView!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        addSlideMenuButton()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func ReadMore(_ sender: Any) {
        let aboutpage = storyboard?.instantiateViewController(withIdentifier: "About") as! About
        navigationController?.pushViewController(aboutpage, animated: true)
    }
    
    @IBAction func PrincipalDesk(_ sender: Any) {
        let pdpage = storyboard?.instantiateViewController(withIdentifier: "PrincipalDesk") as! PrincipalDesk
        navigationController?.pushViewController(pdpage, animated: true)
    }
    
    @IBAction func ChaimanDesk(_ sender: Any) {
        let cdpage = storyboard?.instantiateViewController(withIdentifier: "ChairmanDesk") as! ChairmanDesk
        navigationController?.pushViewController(cdpage, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
