//
//  Sport.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 03/01/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class Sport: BaseViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "cell")
        cell.textLabel?.text = nameArray[indexPath.row]
        cell.detailTextLabel?.text = designationArray[indexPath.row]
        return cell
    }
    
    var nameArray = ["Prof. Dr. P. H. Pawar","prof. Dr. J. B. Pawar","Prof. Dr. A. A. Patil","Prof. Dr. Vidya R. Patil","Prof. Anita S. Patil","Prof. Dr. N. S. Chavan","Prof. S. B. Khairnar","Prof. S. E. Teli","Prof. V. D. Jawral","Prof. P. R. Chaudhari","Prof. Neetin M. Walke"]
    var designationArray = ["Principal","Chairman","Vice-Principal","Vice-Principal","Vice-Principal","Vice-Principal","Member","Member","Member","Member","Member","Member"]

    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var SportView: UITableView!
    override func viewDidLoad() {
        addSlideMenuButton()
        view2.layer.cornerRadius = 10.0
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
