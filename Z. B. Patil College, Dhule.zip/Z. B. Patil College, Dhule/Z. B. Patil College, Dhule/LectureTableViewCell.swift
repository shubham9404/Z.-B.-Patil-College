//
//  LectureTableViewCell.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 02/03/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class LectureTableViewCell: UITableViewCell {

    @IBOutlet weak var LectureImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
