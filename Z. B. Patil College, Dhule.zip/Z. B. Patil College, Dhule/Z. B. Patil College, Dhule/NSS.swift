//
//  NSS.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 03/01/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class NSS: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = viewTable.dequeueReusableCell(withIdentifier: "cell") as! NSSTableViewCell
        cell.nssImage!.image = UIImage(named: imageArray[indexPath.row])
        return cell
    }
    
    
    @IBOutlet weak var viewTable: UITableView!
    var imageArray = ["nss1.jpg","nss2.jpg","nss3.jpg","nss4.jpg","nss5.jpg","nss6.jpg","nss7.jpg","nss8.jpg","nss9.jpg","nss10.jpg"]

    override func viewDidLoad() {
        addSlideMenuButton()
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
