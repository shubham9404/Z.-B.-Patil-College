//
//  AlumniRegistration2.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 02/03/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class AlumniRegistration2: BaseViewController {

    var alumniFirstName = String()
    var alumniMiddleName = String()
    var alumniLastName = String()
    var alumniAddress = String()
    var alumniContact = String()
    var alumniEmail = String()
    var alumniDegree = String()
    var alumniYear = String()
    var alumniSubject = String()
    
    @IBOutlet weak var alumniDesignation: UITextField!
    @IBOutlet weak var alumniCompany: UITextField!
    @IBOutlet weak var alumniCompanyAddress: UITextField!
    
    @IBOutlet weak var registerOutlet: UIButton!
    @IBOutlet weak var view1: UIView!
    override func viewDidLoad() {
        addSlideMenuButton()
        view1.layer.cornerRadius = 10.0
        registerOutlet.layer.cornerRadius = 10.0
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func registerAction(_ sender: UIButton) {
    let insertQuery = "insert into taskTable(taskFName, taskMName, taskLName, taskaddress, taskContact, taskemail, taskdegree, tasksubject, taskyear, taskdesignation, taskcompany, taskcaddress) values ('\(alumniFirstName)','\(alumniMiddleName)','\(alumniLastName)','\(alumniAddress)','\(alumniContact)','\(alumniEmail)','\(alumniDegree)','\(alumniYear)','\(alumniSubject)','\(alumniDesignation.text!)','\(alumniCompany.text!)','\(alumniCompanyAddress.text!)')"
    let isSuccess = alumniDatabase.sharedObject.executeQuery(query: insertQuery)
    if isSuccess
    {
        print("insert: Success")
    }
    else
    {
        print("insert: Failed")
    }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
