//
//  AlumniRegistration.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 02/03/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class AlumniRegistration: BaseViewController {

    @IBOutlet weak var AFirstName: UITextField!
    @IBOutlet weak var AMiddleName: UITextField!
    @IBOutlet weak var ALastName: UITextField!
    @IBOutlet weak var AAddress: UITextField!
    @IBOutlet weak var AContactNo: UITextField!
    @IBOutlet weak var AEmail: UITextField!
    @IBOutlet weak var Adegree: UITextField!
    @IBOutlet weak var AYear: UITextField!
    @IBOutlet weak var ASubject: UITextField!
    
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var nextOutlet: UIButton!
    
    override func viewDidLoad() {
        addSlideMenuButton()
        view1.layer.cornerRadius = 10.0
        view2.layer.cornerRadius = 10.0
        nextOutlet.layer.cornerRadius = 10.0
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func nextPage(_ sender: UIButton) {
        let nextAction = storyboard?.instantiateViewController(withIdentifier: "AlumniRegistration2") as! AlumniRegistration2
        nextAction.alumniFirstName = AFirstName.text!
        nextAction.alumniMiddleName = AMiddleName.text!
        nextAction.alumniLastName = ALastName.text!
        nextAction.alumniAddress = AAddress.text!
        nextAction.alumniContact = AContactNo.text!
        nextAction.alumniEmail = AEmail.text!
        nextAction.alumniDegree = Adegree.text!
        nextAction.alumniYear = AYear.text!
        nextAction.alumniSubject = ASubject.text!
        navigationController?.pushViewController(nextAction, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
