//
//  AlumniOurPride.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 23/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class AlumniOurPride: BaseViewController, UITableViewDataSource {
    
    
    
    
    var name = ["Mr. Ram Shankar Shinde","Ms. nilima Mishra","Mr. Sanjiv dahiwadkar","Mr. Vinayak Chavan","Dr. Mahendra Shirsath","Mr. Hitendra Marathe","Mr. Hemraj Bagul","Mr. B. B. Patil","Mr. Sachin Goswami","Mr. Nitin Baviskar","Mr. Mahendra Marathe","Mr. Nitin Bang","Mr. A. C. Natu","Mr. Girish Kulkarni","Mr. Bhupendra Lahamge"]
    
    var post = ["Cabinet Minister","Social Worker","President & CEO IndiSoft","Secretory Counselor, Indian Embesy","Deputy Director, Ministry of Commerce","Colonel Army","Senior Assisent Director","Registrar, KBCNMU, Jalgaon","Director, Marathi Serial","Entrepreneur","S/W Project Manager, USA","Businessman","Civil Judge, Mumbai","Project Director, Aasha Foundation","Political Leader"]
    
    var photo = ["1.jpeg","2.jpeg","3.jpeg","4.jpeg","5.jpeg","6.jpeg","7.jpeg","8.jpeg","9.jpeg","10.jpeg","11.jpeg","12.jpeg","13.jpeg","14.jpeg","15.jpeg"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return photo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let alumniop = tableView.dequeueReusableCell(withIdentifier: "alumniop") as! OurPrideTableViewCell
        alumniop.name.text = name[indexPath.row]
        alumniop.post.text = post[indexPath.row]
        alumniop.photo!.image = UIImage(named: photo[indexPath.row])
        //tableView.estimatedRowHeight = 50
        
        return alumniop
        
    }
    
    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
