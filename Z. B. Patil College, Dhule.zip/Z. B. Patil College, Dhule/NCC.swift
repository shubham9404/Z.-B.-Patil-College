//
//  NCC.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 03/01/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class NCC: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nccImageArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = nccView.dequeueReusableCell(withIdentifier: "cell") as! NCCTableViewCell
        cell.nccImage!.image = UIImage(named: nccImageArray[indexPath.row])
        return cell
    }
    
    var nccImageArray = ["page01.jpg","page02.jpg","page03.jpg","page04.jpg","page05.jpg","page06.jpg","page07.jpg","page08.jpg","page09.jpg","page10.jpg","page11.jpg","page12.jpg","page13.jpg","page14.jpg","page15.jpg","page16.jpg","page17.jpg","page18.jpg","page19.jpg","page20.jpg","page21.jpg","page22.jpg"]
    
    @IBOutlet weak var nccView: UITableView!
    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
