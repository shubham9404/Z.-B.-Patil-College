//
//  Gathering.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 03/01/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class Gathering: BaseViewController,  UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = gatheringView.dequeueReusableCell(withIdentifier: "cell") as! GatheringTableViewCell
        cell.gatheringImage!.image = UIImage(named: imageArray[indexPath.row])
        return cell
    }
    
    @IBOutlet weak var gatheringView: UITableView!
    var imageArray = ["gathering1.jpg","gathering2.jpg","gathering3.jpg","gathering4.jpg","gathering5.jpg","gathering6.jpg"]
    
    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
