//
//  Biotech.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 25/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class Biotech: BaseViewController {

    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet var biotechOutletCollection: [UIButton]!
    
    @IBAction func about(_ sender: Any) {
        biotechOutletCollection.forEach { (button) in
            button.isHidden = !button.isHidden
    }
    }
}
