//
//  NCCTableViewCell.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 03/03/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import UIKit

class NCCTableViewCell: UITableViewCell {

    @IBOutlet weak var nccImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
