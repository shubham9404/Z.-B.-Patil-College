//
//  ContactUs.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 19/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ContactUs: BaseViewController {
    
    
    
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var alumnibutton: UIButton!
    @IBAction func alumniPage(_ sender: UIButton) {
        let next = storyboard?.instantiateViewController(withIdentifier: "AlumniRegistration") as! AlumniRegistration
        navigationController?.pushViewController(next, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view1.layer.cornerRadius = 10.0
        view2.layer.cornerRadius = 10.0
        alumnibutton.layer.cornerRadius = 10.0
        addSlideMenuButton()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
