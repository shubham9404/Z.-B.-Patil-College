//
//  AlumniDatabase.swift
//  Z. B. Patil College, Dhule
//
//  Created by Shubham Shinde on 02/03/20.
//  Copyright © 2020 Shubham. All rights reserved.
//

import Foundation
import SQLite3

class alumniDatabase
{
    var firstName = [String]()
    var middleName = [String]()
    var lastName = [String]()
    var address = [String]()
    var contact = [String]()
    var email = [String]()
    var degree = [String]()
    var subject = [String]()
    var year = [String]()
    var designation = [String]()
    var company = [String]()
    var companyAddress = [String]()
    static let sharedObject = alumniDatabase()
    
    func getDatabasePath() -> String
    {
        let direction = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = direction.first!
        return path+"college.sqlite"
    }
    
    func executeQuery(query:String)-> Bool
    {
        var success = false
        var db:OpaquePointer?
        var stm:OpaquePointer?
        let path = getDatabasePath()
        if sqlite3_open(path, &db) == SQLITE_OK
        {
            if sqlite3_prepare(db, query, -1, &stm, nil) == SQLITE_OK
            {
                if(sqlite3_step(stm)) == SQLITE_DONE
                {
                    success = true
                    sqlite3_finalize(stm!)
                    sqlite3_close(db)
                }
            }
            else
                {
                    print("Error in prepare:\(sqlite3_step(stm))")
                }
        }
        else
        {
            print("Error in opening:\(String(describing: sqlite3_errmsg(stm)))")
        }
        return success
    }
    
    func selectAllTask(query:String)
    {
        var db:OpaquePointer?
        var stmt:OpaquePointer?
        let path = getDatabasePath()
        if sqlite3_open(path, &db) == SQLITE_OK
        {
            if sqlite3_prepare(db, query, -1, &stmt, nil) == SQLITE_OK
            {
                firstName.removeAll()
                middleName.removeAll()
                lastName.removeAll()
                address.removeAll()
                contact.removeAll()
                email.removeAll()
                degree.removeAll()
                subject.removeAll()
                year.removeAll()
                designation.removeAll()
                company.removeAll()
                companyAddress.removeAll()
                while (sqlite3_step(stmt)) == SQLITE_ROW
                {
                    let taskFName = sqlite3_column_text(stmt, 0)
                    let tFName = String(cString: taskFName!)
                    firstName.append(tFName)
                    
                    let taskMName = sqlite3_column_text(stmt, 1)
                    let tMName = String(cString: taskMName!)
                    middleName.append(tMName)
                    
                    let taskLName = sqlite3_column_text(stmt, 2)
                    let tLName = String(cString: taskLName!)
                    lastName.append(tLName)
                    
                    let taskaddress = sqlite3_column_text(stmt, 3)
                    let taddress = String(cString: taskaddress!)
                    address.append(taddress)
                    
                    let taskContact = sqlite3_column_text(stmt, 4)
                    let tcontact = String(cString: taskContact!)
                    contact.append(tcontact)
                    
                    let taskemail = sqlite3_column_text(stmt, 5)
                    let temail = String(cString: taskemail!)
                    email.append(temail)
                    
                    let taskdegree = sqlite3_column_text(stmt, 6)
                    let tdegree = String(cString: taskdegree!)
                    degree.append(tdegree)
                    
                    let tasksubject = sqlite3_column_text(stmt, 7)
                    let tsubject = String(cString: tasksubject!)
                    subject.append(tsubject)
                    
                    let taskyear = sqlite3_column_text(stmt, 8)
                    let tyear = String(cString: taskyear!)
                    year.append(tyear)
                    
                    let taskdesignation = sqlite3_column_text(stmt, 9)
                    let tdesignation = String(cString: taskdesignation!)
                    designation.append(tdesignation)
                    
                    let taskcompany = sqlite3_column_text(stmt, 10)
                    let tcompany = String(cString: taskcompany!)
                    company.append(tcompany)
                    
                    let taskcaddress = sqlite3_column_text(stmt, 11)
                    let tcaddress = String(cString: taskcaddress!)
                    companyAddress.append(tcaddress)
                    
                }
                print(firstName)
                print(middleName)
                print(lastName)
                print(address)
                print(contact)
                print(email)
                print(degree)
                print(subject)
                print(year)
                print(designation)
                print(company)
                print(companyAddress)
                }
            else
            {
                print("Error in prepare:\(sqlite3_step(stmt))")
            }
        }
        else
        {
            print("Error in open:\(String(describing: sqlite3_errmsg(stmt)))")
        }
    }
    
    func createTable()
    {
        let createQuery = "create table if not exists taskTable(taskFName text, taskMName text, taskLName text, taskaddress text, taskContact text, taskemail text, taskdegree text, tasksubject text, taskyear text, taskdesignation text, taskcompany text, taskcaddress text)"
        let isSuccess = executeQuery(query: createQuery)
        if isSuccess
        {
            print("create table successfully")
        }
        else
        {
            print("table creation failed")
        }
    }
}
