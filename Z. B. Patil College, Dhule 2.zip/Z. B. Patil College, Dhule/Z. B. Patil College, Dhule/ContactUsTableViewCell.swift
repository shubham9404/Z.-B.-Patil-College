//
//  ContactUsTableViewCell.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 23/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ContactUsTableViewCell: UITableViewCell {

    @IBOutlet weak var contacTitle: UILabel!
    
    @IBOutlet weak var contactDetails: UITextView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
