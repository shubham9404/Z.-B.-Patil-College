//
//  AlumniOurPride.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 23/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class AlumniOurPride: BaseViewController, UITableViewDataSource {
    
    
    //var srno = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"]
    
    //var name = ["Mr. Ram Shankar Shinde","Ms. nilima Mishra","Mr. Sanjiv dahiwadkar","Mr. Vinayak Chavan","Dr. Mahendra Shirsath","Mr. Hitendra Marathe","Mr. Hemraj Bagul","Mr. B. B. Patil","Mr. Sachin Goswami","Mr. Nitin Baviskar","Mr. Mahendra Marathe","Mr. Nitin Bang","Mr. A. C. Natu","Mr. Girish Kulkarni","Mr. Bhupendra Lahamge"]
    
    //var post = ["Cabinet Minister Water Conservation","Social Worker","President & CEO,IndiSoft","First Secretary(Press) Counselor Indian Embassy, Beijing, China","Deputy Director ( Tech.) EIC, Ministry Of Commerce and Industries, Government Of India , New Delhi","Colonel Army [2 Sena Medal Recipient]","Senior Asst. director(Info) at DGIPR, Mantralaya, Govt. of Maharashtra","Registrar , NMU, Jalgaon.","Director, Marathi Serials, Drams & Movies – Mumbai.","Entrepreneur PN Automation INC., USA.","S/W Project Manager, USA","Businessman, President Dhule Industrial Corporation","Civil Judge, Mumbai.","Project Director, Asha Foundation's INDEEA, Jalgaon","Corporate Member & Political Leader"]
    
    var photo = ["honchairman1.jpeg",/*"Ms. nilima Mishra.jpg","Mr. Sanjiv dahiwadkar.jpg","Mr. Vinayak Chavan.jpg","Dr. Mahendra Shirsath.jpg","Mr. Hitendra Marathe.jpg","Mr. Hemraj Bagul.jpg","Mr. B. B. Patil.jpg","Mr. Sachin Goswami.jpg","Mr. Nitin Baviskar.jpg","Mr. Mahendra Marathe.jpg","Mr. Nitin Bang.jpg","Mr. A. C. Natu.jpg","Mr. Girish Kulkarni.jpg","Mr. Bhupendra Lahamge.jpg"*/]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return photo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let alumniop = tableView.dequeueReusableCell(withIdentifier: "alumniop") as! OurPrideTableViewCell
        //alumniop.serialno.text = srno[indexPath.row]
        //alumniop.name.text = name[indexPath.row]
        //alumniop.post.text = post[indexPath.row]
        alumniop.photo!.image = UIImage(named: photo[indexPath.row])
        tableView.estimatedRowHeight = 50
        
        return alumniop
        
    }
    
    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
