//
//  ViewController.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 16/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ViewController: BaseViewController {


    override func viewDidLoad() {
        //addSlideMenuButton()
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func nextButton(_ sender: Any) {
        let nextp = storyboard?.instantiateViewController(withIdentifier: "HomePage") as! HomePage
        navigationController?.pushViewController(nextp, animated: true)
    }
}

