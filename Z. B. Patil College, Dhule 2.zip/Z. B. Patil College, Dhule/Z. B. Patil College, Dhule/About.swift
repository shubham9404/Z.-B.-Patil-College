//
//  About.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 16/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class About: BaseViewController {
    
    @IBOutlet weak var View1: UIView!
    
    @IBOutlet weak var AboutTitle: UILabel!
    
    @IBOutlet weak var View2: UIView!
    
    @IBOutlet weak var AboutTrus: UILabel!
    
    @IBOutlet weak var ATText: UITextView!
    
    @IBOutlet weak var View3: UIView!
    
    @IBOutlet weak var AboutCollege: UILabel!
    
    @IBOutlet weak var ACText: UITextView!
    override func viewDidLoad() {
        addSlideMenuButton()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

