//
//  ContactUs.swift
//  Z. B. Patil College, Dhule
//
//  Created by student14 on 19/09/19.
//  Copyright © 2019 Shubham. All rights reserved.
//

import UIKit

class ContactUs: BaseViewController, UITableViewDataSource {
    
    @IBOutlet weak var View1: UIView!
    var contactTitle = ["Address","Tel No.","Fax No.","Email"]
    
    var contactDetails = ["Zulal Bhilajirao Patil College, Nanasaheb Adv. Z. B. Patil Road Deopur, Dhule-424002, Maharashtra, India.","02562 -222343","02562 -220678","jaihind@jaihindcollege.ac.in"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ContactUsTableViewCell
        cell.contacTitle.text = contactTitle[indexPath.row]
        cell.contactDetails.text = contactDetails[indexPath.row]
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
